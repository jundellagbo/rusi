    <ul class="nav" id="fresh">
              
              <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-users"></span>Account Lists<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="accountlists" href="#">All Accounts</a>
                  </li>
                  <li>
                    <a id="ca" href="#">Current Accounts</a>
                  </li>
                  <li>
                    <a id="history" href="#">Account History</a>
                  </li>
                  
                </ul>
              </li>
               <li><a id="payments" href="#" class="">
                <span aria-hidden="true" class="fa fa-ruble"></span>Payments</a>
              </li>
               <li><a id="reports" href="#">
                <span aria-hidden="true" class="fa fa-bar-chart-o"></span>Reports</a>
              </li>
               
                <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-edit"></span>Application<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="application" href="#">Add Applicant</a>
                  </li>
                  <li>
                    <a id="approval" href="#">Pending Applicant</a>
                  </li>
              
                </ul>
              </li>
               <!-- <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-list-alt"></span>Stocks<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="addstocks" href="#">Add Stocks</a>
                  </li>
                  <li>
                    <a id="liststocks" href="#">List of Stocks</a>
                  </li>
              
                </ul>
              </li> -->
              <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-user"></span>Users<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="addusers" href="#">Add Users</a>
                  </li>
                  <li>
                    <a id="userlist" href="#">Users List</a>
                  </li>
              
                </ul>
              </li>
              
               <li><a id="page" href="#">
                <span aria-hidden="true" class="fa fa-tasks"></span>Statistics</a>
              </li>
               <li><a id="logs" href="#">
                <span aria-hidden="true" class="fa fa-desktop"></span>User logs</a>
              </li>
               <li><a id="transactions" href="#">
                <span aria-hidden="true" class="fa fa-table"></span>Transactions</a>
              </li>
              
            </ul>