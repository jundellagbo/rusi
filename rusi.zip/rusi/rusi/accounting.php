    <ul class="nav">
            
              <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-users"></span>Account Lists<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="accountlists" href="#">All Accounts</a>
                  </li>
                  <li>
                    <a id="ca" href="#">Current Accounts</a>
                  </li>
                  <li>
                    <a id="history" href="#">Account History</a>
                  </li>
                  
                </ul>
              </li>
               <li><a id="payments" href="#">
                <span aria-hidden="true" class="fa fa-dollar"></span>Payments</a>
              </li>
               <li><a id="reports" href="#">
                <span aria-hidden="true" class="fa fa-bar-chart-o"></span>Reports</a>
              </li>
               
                <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-edit"></span>Application<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="application" href="#">Add Applicant</a>
                  </li>
                  <li>
                    <a id="approval" href="#">Pending Applicant</a>
                  </li>
              
                </ul>
              </li>
              
            
              
             
               <li><a id="transactions" href="#">
                <span aria-hidden="true" class="fa fa-table"></span>Transactions</a>
              </li>
              
            </ul>