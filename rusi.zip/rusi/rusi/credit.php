    <ul class="nav">
             
            
                <li class="dropdown"><a data-toggle="dropdown" href="#">
                <span aria-hidden="true" class="fa fa-edit"></span>Application<b class="caret"></b></a>
                <ul class="dropdown-menu">
                  <li>
                    <a id="application" href="#">Add Applicant</a>
                  </li>
                  <li>
                    <a id="approval" href="#">Pending Applicant</a>
                  </li>
              
                </ul>
              </li>
              
            
              
             
              
              
            </ul>