
<div class="animated fadeInDown">
<div class="row hidden-print">
          <div class="col-md-12">
            <div class="widget-container fluid-height">
              <div class="heading">
              </div>
              <div class="widget-content padded">
              <center><img src="images/logo-big.png"> <br><br><br><label>Copyright 2016 RUSI Motorcycles Inc. Delivery System</label></center>
              </div>
            </div>
          </div>
</div>
</div>
